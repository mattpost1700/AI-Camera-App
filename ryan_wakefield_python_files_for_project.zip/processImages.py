from PIL import Image, ImageOps
import os
import glob



#If directories aren't made, make them
os.chdir("raw")
for i in range(10):
    if os.path.isdir(str(i)) is False:
        os.makedirs(str(i))
        
os.chdir("..")
os.chdir("data/Digits_Dataset_2")
for i in range(10):
    if os.path.isdir(str(i)) is False:
        os.makedirs(str(i))


os.chdir("../..")
os.chdir("raw")

savePath = "/home/ryan/m_learning/data/Digits_Dataset_2"
openPath = "/home/ryan/m_learning/raw"
targetSize = (224,224)

rotations = [15,-15]
positions = [(0,0),
             (112,0),
             (0,112),
             (112,112),
             (56,56,)]
sizes = [(112,112)]



def create_rotation(image, path, rotation):
    out = image.rotate(rotation)
    out.save(path, "jpeg")

def create_reduction(image, path, size, position):
    canvas = Image.new('RGB', (224,224), 'white')
    reduction = image.resize(size)
    canvas.paste(reduction, position)
    canvas.save(path, "jpeg")

def next_index(index):
    return str(int(index) + 1)
    
#Iterate over every file, open image, resize image, and save to different directory
for i in range(10):
    folder =  os.listdir(openPath + "/" + str(i))
    index = "100"
    for file in folder:
        #basic setup
        temp = Image.open(openPath + "/" + str(i) + "/" + file)
        temp = ImageOps.exif_transpose(temp)#Needed to fix weird rotations
        temp = temp.resize(targetSize)
        temp.save(savePath + "/{}/".format(str(i)) + "IMG_" + index + ".JPG","jpeg")
        index = next_index(index)

        for angle in rotations:
            create_rotation(temp,
                            savePath + "/{}/".format(str(i)) + "IMG_" + index + ".JPG",
                            angle)
            index = next_index(index)
        for xy in positions:
            create_reduction(temp,
                             savePath + "/{}/".format(str(i)) + "IMG_" + index + ".JPG",
                             sizes[0],
                             xy)
            index = next_index(index)
       
    print("Folder {} is done.".format(str(i)))       
            
