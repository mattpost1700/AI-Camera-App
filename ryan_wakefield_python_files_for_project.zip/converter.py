import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential, load_model, Model


input_version = "0.3"
model_path = "models/mobile_model_digits_trained_{}.h5".format(input_version)
model = load_model(model_path)

# Convert the model.
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()


output_version = "0.3"
save_path = "/home/ryan/m_learning/tflite/model_for_digits_ver_{}.tflite".format(output_version)
# Save the model.
with open(save_path, 'wb') as f:
  f.write(tflite_model)
